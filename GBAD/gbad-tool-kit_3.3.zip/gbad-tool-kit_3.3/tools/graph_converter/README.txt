graph_converter is a tool to convert GBAD-MDL input files from the old format (pre-version 3.0),  (i.e., no "#" or "//" characters) to the new format.

To install:
Run "make" to compile graph_converter.c.

To run:
Type: "graph_converter [graph name].g"
This will create a new file named [graph name].g.g which is in the new input format.
